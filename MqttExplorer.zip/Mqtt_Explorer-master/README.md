# Mqtt
just to remember

Mosquitto is an open source message broker that implements the MQ Telemetry Transport protocol version 3.1 and 3.1.1 MQTT provides a lightweight method of carrying out messaging using a publish/subscribe model. This makes it suitable for "machine to machine" messaging such as with low power sensors or mobile devices such as phones, embedded computers or micro-controllers like the Arduino.


for mosquitto command line: refer http://www.steves-internet-guide.com/mosquitto_pub-sub-clients/
