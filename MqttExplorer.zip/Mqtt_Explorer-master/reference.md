mqtt vs amqp
https://vasters.com/blog/From-MQTT-to-AMQP-and-back/

interoperability
https://blogs.sap.com/2016/02/21/uniting-amqp-and-mqtt-message-brokering-with-rabbitmq/

for mosquitto command line: refer http://www.steves-internet-guide.com/mosquitto_pub-sub-clients/
